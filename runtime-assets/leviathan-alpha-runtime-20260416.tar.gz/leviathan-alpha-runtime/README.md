# Leviathan Alpha Runtime

Leviathan Alpha Runtime is a demo-safe agent environment for external testers. It packages an agent runtime plus a Leviathan MCP/API shell. It does not ship AEP core logic, attribution logic, capsule pricing, policy internals, or private audit algorithms.

## What This Contains

- Hermes Agent runtime.
- Leviathan MCP shell.
- API-only client code.
- Local agent configuration.
- Startup and smoke-test scripts.

## What This Does Not Contain

- AEP kernel source.
- causal_funding attribution source.
- Capital Capsule internals.
- Delegation/risk/policy internals.
- Private keys or issued tokens.
- Server-side case, receipt, liability, or report stores.

## Architecture

```text
tester machine / container
  Hermes Agent
  Leviathan MCP shell
  API-only client

Leviathan server
  AEP
  attribution
  delegation
  capital capsules
  policy
  audit chain
  case / receipt / report bundle
```

The tester gets the full user-facing behavior, but the protected logic remains behind the Leviathan API.

## Setup

1. Copy the environment file.

```bash
cp .env.example .env
```

2. Fill these values in `.env`.

```bash
LEVIATHAN_API_BASE_URL=...
LEVIATHAN_API_ACCESS_TOKEN=...
MODEL_API_KEY=...
```

3. Build the runtime.

```bash
docker compose build
```

If the build fails before Leviathan code is copied, first check Docker registry access:

```bash
docker run --rm hello-world
```

If `hello-world` also fails to pull, fix Docker Desktop networking/proxy or load a prebuilt image with `docker load`; this is a Docker registry/network issue, not a Leviathan runtime issue.

4. Run a smoke test.

```bash
./scripts/smoke_test.sh
```

5. Run an API smoke test.

```bash
./scripts/api_smoke_test.sh
```

6. Start Hermes.

```bash
./scripts/start.sh
```

## Demo Prompts

Use these inside Hermes after startup:

```text
用 Leviathan 评估一下我能不能买 5 USDC 的 SOL，不要执行。
```

```text
纸上执行：买 5 USDC 的 SOL。
```

```text
Check whether this Solana token is safe to buy with 5 USDC: DoBAMMqcedjoWV3m7JEU1pAzZjkQqeQzbdLUA2etbonk
```

```text
Paper execute a 5 USDC buy of DoBAMMqcedjoWV3m7JEU1pAzZjkQqeQzbdLUA2etbonk.
```

```text
拿刚刚的 case_id 给我一个可分享审计摘要。
```

## Agent Identity

Do not pass an arbitrary `agent_id` unless Leviathan issued one for the tester. Unknown agent identities are expected to be blocked by AEP. For most alpha tests, leave `agent_id` empty and let the server-side demo profile apply.

## Security Notes

- Keep `.env` private.
- Do not bake tokens into the image.
- Use short-lived tester tokens.
- Rotate tokens after demos.
- This alpha mode sends user intent, target asset, and request metadata to the Leviathan API. It is for demos, hackathons, investor walkthroughs, and controlled trials.

## Expected Behavior

- Low-risk paper trades can be authorized and executed through Leviathan.
- High-risk token requests should be blocked and return a case_id plus reasons.
- Audit summaries are returned through safe redacted endpoints.
- The agent should not bypass Leviathan for value-moving actions because the MCP shell and SOUL boundary both enforce that behavior at the agent layer.
