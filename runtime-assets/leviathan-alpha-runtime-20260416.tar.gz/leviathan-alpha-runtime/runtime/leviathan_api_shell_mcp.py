from __future__ import annotations

import argparse
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from mcp.server.fastmcp import FastMCP as _FastMCP


class PublicFastMCP(_FastMCP):
    """FastMCP variant that exposes only the public Leviathan tool surface."""

    def _setup_handlers(self) -> None:
        self._mcp_server.list_tools()(self.list_tools)
        self._mcp_server.call_tool(validate_input=False)(self.call_tool)


DEFAULT_BASE_URL = "http://127.0.0.1:8792"
DEFAULT_TIMEOUT_SECONDS = 180.0


def _base_url() -> str:
    return os.environ.get("LEVIATHAN_API_BASE_URL", DEFAULT_BASE_URL).strip().rstrip("/")


def _timeout_seconds() -> float:
    try:
        return max(1.0, float(os.environ.get("LEVIATHAN_API_TIMEOUT_SECONDS") or DEFAULT_TIMEOUT_SECONDS))
    except ValueError:
        return DEFAULT_TIMEOUT_SECONDS


def _read_token_file(path: str) -> str:
    if not str(path or "").strip():
        return ""
    try:
        with open(os.path.expanduser(path), encoding="utf-8") as handle:
            return handle.read().strip()
    except OSError:
        return ""


def _access_token(explicit_token: str = "") -> str:
    if str(explicit_token or "").strip():
        return str(explicit_token).strip()
    if os.environ.get("LEVIATHAN_API_ACCESS_TOKEN", "").strip():
        return os.environ["LEVIATHAN_API_ACCESS_TOKEN"].strip()
    return _read_token_file(os.environ.get("LEVIATHAN_API_ACCESS_TOKEN_FILE", ""))


def _json_request(
    method: str,
    path: str,
    *,
    payload: dict[str, Any] | None = None,
    access_token: str = "",
) -> dict[str, Any]:
    headers = {"Accept": "application/json"}
    body: bytes | None = None
    if payload is not None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
    token = _access_token(access_token)
    if token:
        headers["Authorization"] = f"Bearer {token}"

    req = urllib.request.Request(
        f"{_base_url()}{path}",
        data=body,
        headers=headers,
        method=method.upper(),
    )
    try:
        with urllib.request.urlopen(req, timeout=_timeout_seconds()) as response:
            raw = response.read().decode("utf-8")
            parsed = json.loads(raw) if raw.strip() else {}
            return parsed if isinstance(parsed, dict) else {"ok": False, "error": "response_not_object"}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            parsed = json.loads(raw) if raw.strip() else {}
        except json.JSONDecodeError:
            parsed = {"error": raw.strip() or exc.reason}
        if not isinstance(parsed, dict):
            parsed = {"error": str(parsed)}
        parsed.setdefault("ok", False)
        parsed.setdefault("status_code", exc.code)
        return parsed
    except urllib.error.URLError as exc:
        return {"ok": False, "error": f"remote_api_unreachable: {exc.reason}"}
    except TimeoutError:
        return {"ok": False, "error": "remote_api_timeout"}


def _payload(
    *,
    text: str = "",
    request: Any | None = None,
    agent_id: str = "",
    authority_pubkey: str = "",
    runtime_type: str = "generic-agent",
    framework: str = "hermes-agent",
    session_id: str = "",
    default_network: str = "paper",
) -> dict[str, Any]:
    doc: dict[str, Any] = {"default_network": default_network or "paper"}
    if str(text or "").strip():
        doc["text"] = str(text).strip()
    if request is not None:
        doc["request"] = request
    if str(agent_id or "").strip():
        doc["agent_id"] = str(agent_id).strip()
    if str(authority_pubkey or "").strip():
        doc["authority_pubkey"] = str(authority_pubkey).strip()
    if str(runtime_type or "").strip():
        doc["runtime_type"] = str(runtime_type).strip()
    if str(framework or "").strip():
        doc["framework"] = str(framework).strip()
    if str(session_id or "").strip():
        doc["session_id"] = str(session_id).strip()
    return doc


def _requests_execution(text: str) -> bool:
    lowered = str(text or "").strip().lower()
    if not lowered:
        return False
    no_execute_markers = (
        "do not execute",
        "without execution",
        "don't execute",
        "dont execute",
        "check only",
        "evaluate only",
        "review only",
        "只评估",
        "不要执行",
        "不执行",
        "仅评估",
        "只检查",
    )
    if any(marker in lowered for marker in no_execute_markers):
        return False
    execution_markers = (
        "execute",
        "run",
        "place order",
        "submit order",
        "perform trade",
        "paper execute",
        "执行",
        "纸上执行",
        "下单",
        "进行交易",
    )
    value_markers = (
        "buy",
        "sell",
        "trade",
        "swap",
        "pay",
        "bridge",
        "approve",
        "加仓",
        "减仓",
        "买",
        "卖",
        "交易",
        "支付",
        "桥",
        "授权",
    )
    return any(marker in lowered for marker in execution_markers) and any(marker in lowered for marker in value_markers)


mcp = PublicFastMCP(
    name="leviathan-api-shell-mcp",
    instructions=(
        "API-only Leviathan shell. It contains no AEP, attribution, risk, policy, capsule, "
        "pricing, review, or liability internals. Use evaluate_action only for explicit check-only "
        "requests. Use run_action for value-moving requests. Use get_presentable_case and "
        "export_report_bundle for audit/report outputs. Never invent execution results."
    ),
)


@mcp.tool(
    name="evaluate_action",
    title="Evaluate Action",
    description="Check-only review; use only when the user explicitly asks to evaluate without execution.",
    structured_output=True,
)
def evaluate_action(
    access_token: str = "",
    text: str = "",
    request: Any | None = None,
    agent_id: str = "",
    authority_pubkey: str = "",
    runtime_type: str = "generic-agent",
    framework: str = "hermes-agent",
    session_id: str = "",
    default_network: str = "paper",
) -> dict[str, Any]:
    payload = _payload(
        text=text,
        request=request,
        agent_id=agent_id,
        authority_pubkey=authority_pubkey,
        runtime_type=runtime_type,
        framework=framework,
        session_id=session_id,
        default_network=default_network,
    )
    if request is None and _requests_execution(text):
        response = _json_request("POST", "/v1/run", payload=payload, access_token=access_token)
        response["shell_auto_rerouted_from"] = "evaluate_action"
        response["shell_auto_reroute_reason"] = "explicit_execution_request"
        return response
    return _json_request("POST", "/v1/evaluate", payload=payload, access_token=access_token)


@mcp.tool(
    name="run_action",
    title="Run Action",
    description="Use for buy/sell/add/reduce/execute/run/trade/pay/bridge requests.",
    structured_output=True,
)
def run_action(
    access_token: str = "",
    text: str = "",
    request: Any | None = None,
    agent_id: str = "",
    authority_pubkey: str = "",
    runtime_type: str = "generic-agent",
    framework: str = "hermes-agent",
    session_id: str = "",
    default_network: str = "paper",
) -> dict[str, Any]:
    return _json_request(
        "POST",
        "/v1/run",
        payload=_payload(
            text=text,
            request=request,
            agent_id=agent_id,
            authority_pubkey=authority_pubkey,
            runtime_type=runtime_type,
            framework=framework,
            session_id=session_id,
            default_network=default_network,
        ),
        access_token=access_token,
    )


@mcp.tool(name="get_case", title="Get Case", description="Fetch the public case summary by case_id.", structured_output=True)
def get_case(access_token: str = "", case_id: str = "") -> dict[str, Any]:
    quoted = urllib.parse.quote(str(case_id or "").strip(), safe="")
    if not quoted:
        return {"ok": False, "error": "case_id is required"}
    return _json_request("GET", f"/v1/cases/{quoted}", access_token=access_token)


@mcp.tool(
    name="get_presentable_case",
    title="Get Presentable Case",
    description="Fetch the safe redacted audit view by case_id.",
    structured_output=True,
)
def get_presentable_case(access_token: str = "", case_id: str = "") -> dict[str, Any]:
    quoted = urllib.parse.quote(str(case_id or "").strip(), safe="")
    if not quoted:
        return {"ok": False, "error": "case_id is required"}
    return _json_request("GET", f"/v1/cases/{quoted}/presentable", access_token=access_token)


@mcp.tool(
    name="export_report_bundle",
    title="Export Report Bundle",
    description="Export a research/report bundle for a case_id.",
    structured_output=True,
)
def export_report_bundle(access_token: str = "", case_id: str = "") -> dict[str, Any]:
    case_id_clean = str(case_id or "").strip()
    if not case_id_clean:
        return {"ok": False, "error": "case_id is required"}
    return _json_request("POST", "/v1/export-report", payload={"case_id": case_id_clean}, access_token=access_token)


def main() -> int:
    parser = argparse.ArgumentParser(description="Leviathan API-only MCP shell for agent runtimes.")
    parser.add_argument("--transport", choices=("stdio", "streamable-http"), default="stdio")
    parser.add_argument("--host", default="")
    parser.add_argument("--port", type=int, default=8794)
    args = parser.parse_args()
    if args.transport == "streamable-http":
        mcp.settings.host = args.host or "127.0.0.1"
        mcp.settings.port = args.port
    mcp.run(args.transport)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

