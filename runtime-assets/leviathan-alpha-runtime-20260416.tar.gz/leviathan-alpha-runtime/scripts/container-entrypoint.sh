#!/usr/bin/env bash
set -euo pipefail

export HERMES_HOME="${HERMES_HOME:-/opt/data}"
mkdir -p "${HERMES_HOME}/.hermes" "${HERMES_HOME}/.leviathan"

if [[ -z "${LEVIATHAN_API_BASE_URL:-}" ]]; then
  echo "LEVIATHAN_API_BASE_URL is required" >&2
  exit 2
fi

if [[ -z "${LEVIATHAN_API_ACCESS_TOKEN:-}" && -z "${LEVIATHAN_API_ACCESS_TOKEN_FILE:-}" ]]; then
  echo "LEVIATHAN_API_ACCESS_TOKEN or LEVIATHAN_API_ACCESS_TOKEN_FILE is required" >&2
  exit 2
fi

if [[ -n "${LEVIATHAN_API_ACCESS_TOKEN:-}" ]]; then
  umask 077
  printf "%s" "${LEVIATHAN_API_ACCESS_TOKEN}" > "${HERMES_HOME}/.leviathan/token"
  export LEVIATHAN_API_ACCESS_TOKEN_FILE="${HERMES_HOME}/.leviathan/token"
  unset LEVIATHAN_API_ACCESS_TOKEN
fi

export LEVIATHAN_API_TIMEOUT_SECONDS="${LEVIATHAN_API_TIMEOUT_SECONDS:-180}"
export MODEL_PROVIDER="${MODEL_PROVIDER:-custom}"
export MODEL_BASE_URL="${MODEL_BASE_URL:-https://integrate.api.nvidia.com/v1}"
export MODEL_ID="${MODEL_ID:-qwen/qwen3-next-80b-a3b-instruct}"

if [[ -n "${MODEL_API_KEY:-}" && -z "${OPENAI_API_KEY:-}" ]]; then
  export OPENAI_API_KEY="${MODEL_API_KEY}"
fi

cat > "${HERMES_HOME}/.hermes/config.yaml" <<YAML
model:
  provider: ${MODEL_PROVIDER}
  base_url: ${MODEL_BASE_URL}
  model: ${MODEL_ID}
mcp_servers:
  leviathan_api_shell_stdio:
    command: /opt/hermes-venv/bin/python
    args:
      - /opt/leviathan/leviathan_api_shell_mcp.py
      - --transport
      - stdio
    timeout: 180
    connect_timeout: 60
    env:
      LEVIATHAN_API_BASE_URL: ${LEVIATHAN_API_BASE_URL}
      LEVIATHAN_API_ACCESS_TOKEN_FILE: ${LEVIATHAN_API_ACCESS_TOKEN_FILE}
      LEVIATHAN_API_TIMEOUT_SECONDS: "${LEVIATHAN_API_TIMEOUT_SECONDS}"
YAML

cp /opt/leviathan/SOUL.md "${HERMES_HOME}/.hermes/SOUL.md"

if [[ "${1:-}" == "shell-smoke-test" ]]; then
  exec /opt/hermes-venv/bin/python /opt/leviathan/leviathan_api_shell_mcp.py --help
fi

if [[ "${1:-}" == "api-smoke-test" ]]; then
  exec /opt/hermes-venv/bin/python - <<'PY'
import importlib.util
import json
from pathlib import Path

runtime_path = Path("/opt/leviathan/leviathan_api_shell_mcp.py")
spec = importlib.util.spec_from_file_location("leviathan_api_shell_mcp", runtime_path)
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)

result = module.evaluate_action(
    text="Evaluate whether a 1 USDC paper buy of SOL is allowed. Do not execute.",
    session_id="leviathan-alpha-runtime-api-smoke-test",
)
print(json.dumps({
    "ok": bool(result.get("ok")),
    "case_id": result.get("case_id"),
    "service": result.get("service"),
    "action": result.get("action"),
    "error": result.get("error"),
}, ensure_ascii=False, indent=2))
if not result.get("ok"):
    raise SystemExit(1)
PY
fi

exec "$@"
