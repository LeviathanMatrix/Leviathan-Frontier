#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

if [[ ! -f .env ]]; then
  echo "Missing .env. Run: cp .env.example .env, then fill endpoint/token/model key." >&2
  exit 2
fi

docker compose run --rm leviathan-alpha-runtime api-smoke-test

